/**
 * @param {Object} object
 * @return {string}
 */
function valueOf(object) {}

/**
 * @param {Object} object
 * @return {string}
 */
function toString(object) {}

/**
 * @param {Object} object
 * @return {string}
 */
function toSource(object) {}

/**
 * @param {Object} object
 * @return {string}
 */
function constructor(object) {}